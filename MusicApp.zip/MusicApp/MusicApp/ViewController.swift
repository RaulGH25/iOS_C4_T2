//
//  ViewController.swift
//  MusicApp
//
//  Created by Raul Guerra Hernandez on 12/24/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit
import AVFoundation


class ViewController: UIViewController {
    
    
    @IBOutlet weak var labelTitle: UILabel!
    
    @IBOutlet weak var imageCD: UIImageView!
    
    
    private var reproductor : AVAudioPlayer!
    var volumenActual : Float = 1.0
    
    private let sonidoC1URL = Bundle.main.url(forResource: "BoxCatGames_EpicSong_10s", withExtension: "m4a")
    private let sonidoC2URL = Bundle.main.url(forResource: "brokeForFree_nightOwl_10s", withExtension: "m4a")
    private let sonidoC3URL = Bundle.main.url(forResource: "Jahzzar_Siesta_10s", withExtension: "m4a")
    private let sonidoC4URL = Bundle.main.url(forResource: "TheKyotoConnection_TheFaithtfulDog_10s", withExtension: "m4a")
    private let sonidoC5URL = Bundle.main.url(forResource: "Tours_Enthusiast_10s", withExtension: "m4a")
    
    private let titleC1 = "Epic Song"
    private let titleC2 = "Night Owl"
    private let titleC3 = "Siesta"
    private let titleC4 = "The Faithtful Dog"
    private let titleC5 = "Enthusiast"
    
    
    private let imageC1name = "BoxCatGames_EpicSong.jpeg"
    private let imageC2name = "brokeForFree_nightOwl.jpeg"
    private let imageC3name = "Jahzzar_Siesta.jpeg"
    private let imageC4name = "TheKyotoConnection_TheFaithtfulDog.jpeg"
    private let imageC5name = "Tours_Enthusiast.jpeg"
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //let sonidoC1URL = Bundle.main.url(forResource: "BoxCatGames_EpicSong_10s", withExtension: "m4a")
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC1URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        
    }


    @IBAction func actionC1() {
        if reproductor.isPlaying {
            reproductor.stop()
        }
        
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC1URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        labelTitle.text = titleC1
        
        let imageView = UIImageView(image: UIImage(named: imageC1name)!)
        imageCD.addSubview(imageView)
    }
    
    
    @IBAction func actionC2() {
        if reproductor.isPlaying {
            reproductor.stop()
        }
        
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC2URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        labelTitle.text = titleC2
        
        let imageView = UIImageView(image: UIImage(named: imageC2name)!)
        imageCD.addSubview(imageView)
    }
    
    
    @IBAction func actionC3() {
        if reproductor.isPlaying {
            reproductor.stop()
        }
        
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC3URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        labelTitle.text = titleC3
        
        let imageView = UIImageView(image: UIImage(named: imageC3name)!)
        imageCD.addSubview(imageView)
    }
    
    
    @IBAction func actionC4() {
        if reproductor.isPlaying {
            reproductor.stop()
        }
        
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC4URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        labelTitle.text = titleC4
        
        let imageView = UIImageView(image: UIImage(named: imageC4name)!)
        imageCD.addSubview(imageView)
    }
    
    
    @IBAction func actionC5() {
        if reproductor.isPlaying {
            reproductor.stop()
        }
        
        do{
            try reproductor = AVAudioPlayer(contentsOf: sonidoC5URL!)
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        labelTitle.text = titleC5
        
        let imageView = UIImageView(image: UIImage(named: imageC5name)!)
        imageCD.addSubview(imageView)
    }
 

    
    @IBAction func actionShuffle() {
        
        let randomNum:UInt32 = arc4random_uniform(5) // range is 0 to 4
        let randomInt:Int = Int(randomNum) + 1
        
        if reproductor.isPlaying {
            reproductor.stop()
        }

        
        do{
            switch randomInt {
            case 1:
                try reproductor = AVAudioPlayer(contentsOf: sonidoC1URL!)
                labelTitle.text = titleC1
                let imageView = UIImageView(image: UIImage(named: imageC1name)!)
                imageCD.addSubview(imageView)
            case 2:
                try reproductor = AVAudioPlayer(contentsOf: sonidoC2URL!)
                labelTitle.text = titleC2
                let imageView = UIImageView(image: UIImage(named: imageC2name)!)
                imageCD.addSubview(imageView)
            case 3:
                try reproductor = AVAudioPlayer(contentsOf: sonidoC3URL!)
                labelTitle.text = titleC3
                let imageView = UIImageView(image: UIImage(named: imageC3name)!)
                imageCD.addSubview(imageView)
            case 4:
                try reproductor = AVAudioPlayer(contentsOf: sonidoC4URL!)
                labelTitle.text = titleC4
                let imageView = UIImageView(image: UIImage(named: imageC4name)!)
                imageCD.addSubview(imageView)
            case 5:
                try reproductor = AVAudioPlayer(contentsOf: sonidoC5URL!)
                labelTitle.text = titleC5
                let imageView = UIImageView(image: UIImage(named: imageC5name)!)
                imageCD.addSubview(imageView)
            default:
                print("error al generar el numero aleatorio")
            }
            
        }
        catch{print("error al cargar el archivo de sonido")}
        
        reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        reproductor.play()
        
        
    }
    
    
    
    @IBAction func actionTocar() {
        if !reproductor.isPlaying{
            reproductor.play()
        }
    }
    
    
    @IBAction func actionParar() {
        if reproductor.isPlaying{
            reproductor.pause()
        }
    }
 
    
    @IBAction func actionDetener() {
        if reproductor.isPlaying{
            reproductor.stop()
            reproductor.currentTime = 0.0
        }
    }
    
    
    
    @IBAction func actionVolUp() {
        volumenActual = reproductor.volume
        if volumenActual < 1.0{
            volumenActual = volumenActual + 0.1
            reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        }
        print("Volumen = \(reproductor.volume)")
    }
    
    
    @IBAction func actionVolDown() {
        volumenActual = reproductor.volume
        if volumenActual > 0.0{
            volumenActual = volumenActual - 0.1
            reproductor.setVolume(volumenActual, fadeDuration: 10000.00)
        }
        print("Volumen = \(reproductor.volume)")

    }
    
    
    
}

